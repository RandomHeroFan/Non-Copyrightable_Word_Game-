public class GameText{

    public static String introduction()
    { // First line of the game

        return("   Hello there Players!\n\n       Welcome to....\n\nNon-Copyrightable Word Game!\n\n\nPress [y] if you'd like a tutorial, press [N] to continue");

        }

    public static String tutorial()
    { // Explains how the game works

    return("\n\nTo play the game Player One creates a word which has five letters in it and Player Two is given six chances to get the word correctly.\n\nThe games goes until the word is guessed or all chances have been used. \n\nPress [y] if you'd like more details, press [N] to continue");

    }

    public static String mDetails()
    { // Explain how the game works but with more details

    return("\n\nLet’s assume the word chosen by player 1 is ‘React’.\n\nAs the second player you can choose any word with five letters in it.\n\nLet’s pick ‘Route’. \n\nAfter choosing this word you would end up seeing\n\n ----\n\n R - Green \n O - Red\n U - Red\n T - Yellow\n E - Yellow\n\n ---- \n\nEach of the letters represent different parts of the puzzle. \n\nRed,\t That letter is not in the word. \nYellow,\t That letter is in the word but in a different space. \nGreen,\t That letter is in that exact correct position.\n\nUsing this information you could guess the next word is ‘Reset’.\n\nFrom this you would get\n\n—- \n\n R - Green\n E - Green\n S - Red\n E - Red\n T - Green\n\n----\n\nHere is a special case where you can see that ‘E’s are both green and red\nthis is because there is only a single ‘E’ in the answer and so the other one is red.\n\nWith all this information your final guess may be ‘React’ \n\nin this case you will see ---- \n\n R - Green\n E - Green\n A - Green\n C - Green\n T - Green\n\n----\n\nat this point the game will be over and you will be prompted to play again."
);

    }

    public static String wordChoice() 
    { // Player 1 picks the word

    return("\n\nOk! Now that everything is in order let's commense the game! \n\nPlayer 1, Pick a five letter word for Player 2 to guess!");

    }

    public static String turnSwap() 
        { // Player 1 picks the word

        return("Press [y] to change turns");

        }
    


}
