import java.util.Scanner;

public class Tools{

  public static String validateYes(String prompt) // Meant to ensure that the user entered Y or N
    {

      String yesOrNo;
      Scanner scan = new Scanner(System.in);

      System.out.println(prompt);
      
      yesOrNo = scan.nextLine();

      while(!(yesOrNo.equalsIgnoreCase("Y") || yesOrNo.equalsIgnoreCase("N")))
      {
        System.out.println("\nPlease enter [Y] or [N]");
        System.out.println("\nTry again. " + prompt + "\n");
        yesOrNo = scan.nextLine();

      }

      return yesOrNo;

    }

  public static String validateWords(String prompt) // Meant to ensure that the user entered Y or N
    {

      String word;
      Scanner scan = new Scanner(System.in);

      System.out.println(prompt);
  
      word = scan.nextLine();

      while(!(word.length() == 5))
      {
        System.out.println("\nTry again. " + prompt + "\n");
        word = scan.nextLine();

      }

      return word;

    }

  public static void clearScreen() // Allows for a player to be switched and gets rid of the answer so Player 2 can't cheat
  {  
      System.out.print("\033[H\033[2J");  
      System.out.flush();
    
  }
  
}