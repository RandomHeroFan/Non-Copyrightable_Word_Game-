public class Game{

  String guess; // The words that Player 2 guesses with
  String color; // The color given to a certain letter 
  int att; //Amount of attempts to get the word as player 2.
  String stay; // The variable which determines whether the text will continue or not.

    public Game(){

      this.guess = "";
      this.color = "";
      this.stay = "N";
      this.att = 1;

      }


    
  public void gameStart(Answer answer)
    {

      while(stay.equalsIgnoreCase("n"))
      {

      answer.setAnswer(Tools.validateWords(GameText.wordChoice()));

      stay = Tools.validateYes("Are you sure you would like to choose " + answer.getAnswer() + "?");   

      }

      while(stay.equalsIgnoreCase("n"))
      {
          Tools.validateYes(GameText.turnSwap());

      }
      stay = "n"; // reset the stay variable

      Tools.clearScreen(); // Deletes the answer and switches turns

      System.out.println("Player 2! It is now time to start guessing!");
      
    while(att < 7){    
        while(stay.equalsIgnoreCase("n"))
            {

        guess = Tools.validateWords("Enter a five letter word. You have used " + (att - 1) + " attempts. You only get 6");
        stay = Tools.validateYes("\nAre you sure you would like to choose " + guess + "? Enter [y] or [n]");

            }

        if(guess.equalsIgnoreCase(answer.getAnswer()))
            {
            System.out.print("\n\nWell Done! You have beaten your friend in " + att + " attempts!");
            att = 7; // Takes you out of game
            }
        else if(att == 6)
            {
            System.out.print("\n\bYou've been bested. The word was " + answer.getAnswer() + ". You were getting there though, kinda.");
            att = 7; // Out of the game
            }
            else //The while loop will continue no matter what if else is reached
            {
                System.out.print("\n\n----\n\n");

                for(int i = 0; i < guess.length(); i++) // First loop goes through every letter to print their color
                {

                    if(answer.getAnswer().substring(i, i+1).equalsIgnoreCase(guess.substring(i, i + 1)))
                    { // Letter is in correct position
                       color = " - green";
                    }
                    else if(answer.getAnswer().indexOf(guess.substring(i, i + 1)) > -1)
                    { // Letter is in word but wrong position

                        color = " - Yellow";   
                    }
                    else
                    { // Letter isn't in word
                        color = " - Red";
                    }


                System.out.println(guess.substring(i, i + 1) + color);

                color = "reset"; // Restarts the colors

            }

            System.out.print("\n----\n\n");
            att++; // Displays amount of attempts used
            stay = "n"; // Allows word to be asked again;

        }
    }

        att = 1; // Helps to reset the game;
        stay = "n"; 
        
  }
  
}