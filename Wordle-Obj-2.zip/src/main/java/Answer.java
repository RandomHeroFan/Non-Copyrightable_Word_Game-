public class Answer{

    private String word;

    public Answer(String Word){

        word = Word;

    }

    public String getAnswer(){

      return word;
      
    }

    public void setAnswer(String Word){

      this.word = Word;
      
    }

    public String toString(){

        return word;

    }

}
