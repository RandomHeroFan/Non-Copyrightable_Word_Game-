public class Main {
    public static void main(String args[]) {

        Answer answer = new Answer(""); // The word player 2 needs to guess
        Game game = new Game(); // Will not work without this
        
        String stay = "N"; // The variable which determines whether the text will continue or not.

        stay = (Tools.validateYes(GameText.introduction()));

        if(stay.equalsIgnoreCase("y"))
        {
          stay = (Tools.validateYes(GameText.tutorial()));
          if(stay.equalsIgnoreCase("y"))
          {
              System.out.print(GameText.mDetails());
          }

            stay = "n";
            
        }

    stay = "y"; // activate the while loop

    while(stay == "y"){    
    game.gameStart(answer);
        
    stay = Tools.validateYes(" Would you like to play again? [Y] or [N]");        
    }

    System.out.print("Thanks for Playing! We hope to see you back at Non-Copyrightable Word Game in the future!");
    
}

     
}  
